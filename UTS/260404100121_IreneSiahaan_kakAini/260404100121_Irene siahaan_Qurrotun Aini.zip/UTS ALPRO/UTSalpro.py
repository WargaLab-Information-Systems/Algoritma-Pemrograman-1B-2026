reguler = 40000
vip = 75000
vvip = 100000
total_belanja = 0
total_tiket = 0
pelanggan = 0
member_card = True

if reguler:
    print(" anda mendapatkan diskon minuman! Apakah anda ingin tambahan minum hanya dengan harga 10.000/tiket (Y/N)") 
    if vip or vvip: 
        print("Selamat anda mendaoatkan minuman gratis setelah anda membeli tiket!")

if total_tiket >3:
    if  pelanggan