reguler = 40000
VIP = 75000
VVIP = 100000

while True:
    jumlah = str(input("masukkan jenis tiket"))

    if jumlah = 1:
        tawaran = str(input("apakah mau minuman seharga Rp.10.000? (Y/N)"))
    else:
        print ("mendapat mineral gratis")

